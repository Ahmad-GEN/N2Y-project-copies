﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

[Serializable]
public class Report
{
    #region variables
    private string gametitle; //stores the tittle of games
    private string dateTime; // stores the date and the time of the game, on start

    private string associatedSkillTag;   //stores the skill related to games
    private float playTime; // totla time the game has taken to complete the games
    private int totalNoOfInteraction; // total number of interation user did with games. include all the touhing and draging

    private double percentage; //perc of games the user has played in order to complete the game
    private string selectedMode;// which games mode user choosed to play.

    private string subtitle; // stores subtitle of games
    private bool hasTutorial;
    private int correctlyGuessedSelections; // tell how much of your answers are correct.
    private int wronglyGuessedSelections;  // tell how much of your answers are wrong.





    private List<Keys> selectedKeys; //detailed reporting view of correct letter and incorrect letter typed per session in reporting view 
    #endregion
    #region GetterAndSetter
    public string getGametitle()
    {
        return this.gametitle;
    }

    public void setGametitle(string gametitle)
    {
        this.gametitle = gametitle;
    }

    public string getDatetime()
    {
        return this.dateTime;
    }

    public void setDatetime(string dateTime)
    {
        this.dateTime = dateTime;
    }

    public string getAssociatedskilltag()
    {
        return this.associatedSkillTag;
    }

    public void setAssociatedskilltag(string associatedSkillTag)
    {
        this.associatedSkillTag = associatedSkillTag;
    }

    public float getPlaytime()
    {
        return this.playTime;
    }

    public void setPlaytime(float playTime)
    {
        this.playTime = playTime;
    }

    public int getTotalnoofinteraction()
    {
        return this.totalNoOfInteraction;
    }

    public void setTotalnoofinteraction(int totalNoOfInteraction)
    {
        this.totalNoOfInteraction = totalNoOfInteraction;
    }

    public double getPercentage()
    {
        return this.percentage;
    }

    public void setPercentage(double percentage)
    {
        this.percentage = percentage;
    }

    public string getSelectedmode()
    {
        return this.selectedMode;
    }

    public void setSelectedmode(string selectedMode)
    {
        this.selectedMode = selectedMode;
    }

    public string getSubtitle()
    {
        return this.subtitle;
    }

    public void setSubtitle(string subtitle)
    {
        this.subtitle = subtitle;
    }

    public bool getHastutorial()
    {
        return this.hasTutorial;
    }

    public void isHastutorial(bool hasTutorial)
    {
        this.hasTutorial = hasTutorial;
    }

    public int getCorrectlyguessedselections()
    {
        return this.correctlyGuessedSelections;
    }

    public void setCorrectlyguessedselections(int correctlyGuessedSelections)
    {
        this.correctlyGuessedSelections = correctlyGuessedSelections;
    }

    public int getWronglyguessedselections()
    {
        return this.wronglyGuessedSelections;
    }

    public void setWronglyguessedselections(int wronglyGuessedSelections)
    {
        this.wronglyGuessedSelections = wronglyGuessedSelections;
    }
    public List<Keys> getSelectedkeys()
    {
        return this.selectedKeys;
    }

    public void setSelectedkeys(List<Keys> selectedKeys)
    {
        this.selectedKeys = selectedKeys;
    }
    #endregion
    #region function

    public void /// <summary>
                /// reset the report
                /// </summary>
        ResetReport()
    {
        gametitle = "";
        dateTime = "";
        associatedSkillTag = "";
        playTime = 0f;
        totalNoOfInteraction = 0;
        percentage = 0f;
        selectedMode = "";
        subtitle = "";
        hasTutorial = false;
        correctlyGuessedSelections = 0;
        selectedKeys.Clear();

    }




    #endregion

    [Serializable]
    public class Keys
    {
        public string key;
        public int value;
    }


}
