﻿using UnityEngine.UI;
//using Newtonsoft.Json;
using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using System.Linq;
using System.Linq.Expressions;

public class EventController : MonoBehaviour
{
    #region  variables
    public double totalNoOfLevels = 0;
    private double levelCounter = 0;
    Report report;

    //public string gameTitle;
    int gameTimeCounter = 0;
    public static EventController instance;
    private string POSTAddUserURL = "";
    [HideInInspector]
    public int correctOptionSelectionCounter = 0,wrongOptionSelectionCounter =0;
    #endregion

    #region  function
    void Start()
    {

        instance = this;
        report = new Report();
        //totalPossibleCorrectGuesses = DragAndDrop.Instance.ObjectRef.Length;
     
        InitializeCommonEvents();
    }

    void InitializeCommonEvents()
    {
        setDateTime();
        StartCoroutine(Gametimer(true));
        // Mode("linear");

        // istutorial(false);
        //        completionPercentage();
        // letterStatus("right");
        // letterStatus("right");
        // letterStatus("right");
        Debug.Log("in enable");
        // SaveItemInfo();
        // report.printReport();

    }
    public void setGameTitle(string title)
    {
        report.setGametitle(title);
    }
    void setDateTime()
    {
        report.setDatetime(System.DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"));
    }
    public void setSkillTag(string tag)
    {
        report.setAssociatedskilltag(tag);
    }
    public IEnumerator Gametimer(bool isRunning)
    {
        while (isRunning)
        {
            yield return new WaitForSeconds(1f);
            gameTimeCounter++;
            report.setPlaytime(gameTimeCounter); // in case if user quits in game and we also wanna show the played time
        }
        report.setPlaytime(gameTimeCounter);
    }
    public void StopTime()
    {
        StartCoroutine(Gametimer(false));
    }
    public void CountScreenInteraction()
    {
        if (Input.GetMouseButtonUp(0))
        {
            report.setTotalnoofinteraction(report.getTotalnoofinteraction() + 1);

        }
        if(Input.GetKeyUp(KeyCode.Space))
        {
             report.setTotalnoofinteraction(report.getTotalnoofinteraction() + 1);
        }

    }
    public void GameMode(string mode)
    {
        report.setSelectedmode(mode);
    }
    public void gameSubtitle(string sub)
    {
        report.setSubtitle(sub);
    }
    void istutorial(bool status)
    {
        report.isHastutorial(status);
    }
    public void AddORUpdateLetter(string key)
    {
        Report.Keys tempKey = new Report.Keys(); // creates a temporary key to hols the obj
        tempKey.key = key;// assign the input key to object

        if (report.getSelectedkeys().Exists(kt => kt.key == tempKey.key)) // checking that the provided key is present in dicsionary or not. if it is then it will go inside. 
        {
            report.getSelectedkeys().Find(x => x.key.Contains(key)).value += 1;// will find the object who has its "key" attribute equal to key that is provided and incrementing the value by 1.
        }

        else
        {
            tempKey.value = 1;
            report.getSelectedkeys().Add(tempKey);

        }

    }
    public void PrintReport()
    {
        printReport();
    }
    // public void completionPercentage(double value)
    // {
    //     report.perc += value;
    //     if (report.perc > 100)
    //         report.perc = 100;
    // }
    public void currentGamePercentage()
    {
        levelCounter++;

        if (totalNoOfLevels > 0)
            report.setPercentage((levelCounter / totalNoOfLevels) * 100);

        if (report.getPercentage() > 100)
            report.setPercentage(100);

        PrintReport();
    }
    public void GussedAnswer()
    {
        report.setCorrectlyguessedselections(correctOptionSelectionCounter);
        report.setWronglyguessedselections(wrongOptionSelectionCounter);
    }
    /// <summary>
    /// Update is called every frame, if the MonoBehaviour is enabled.
    /// </summary>
    void Update()
    {
        CountScreenInteraction();

        GussedAnswer();
    }

    #region comments
    //     	public WWW POST()
    // {
    //     WWW www;
    //     Hashtable postHeader = new Hashtable();
    //     postHeader.Add("Content-Type", "application/json");

    //     // convert json string to byte
    //     var formData = System.Text.Encoding.UTF8.GetBytes(report.getReport());

    //     www = new WWW(POSTAddUserURL, formData, postHeader);
    //     StartCoroutine(WaitForRequest(www));
    //     return www;
    // }
    // IEnumerator WaitForRequest(WWW data)
    // {
    //     yield return data; // Wait until the download is done
    //     if (data.error != null)
    //     {
    //         print("There was an error sending request: " + data.error);
    //     }
    //     else
    //     {
    //         print("WWW Request: " + data.text);
    //     }
    // }
    #endregion
    public void sendReport()
    {
        StartCoroutine(Upload());
    }
    IEnumerator Upload()
    {
        // SaveItemInfo(); //this function is used to store the data in json file
        string json = JsonUtility.ToJson(report);
        UnityWebRequest www = UnityWebRequest.Post(POSTAddUserURL, json);
        yield return www.SendWebRequest();

        if (www.isNetworkError || www.isHttpError)
        {
            Debug.Log(www.error);
        }
        else
        {
            Debug.Log("Form upload complete!");
        }
    }


    public void printReport()
    {
        print("GameTitle is: " + report.getGametitle());
        print("Date and time  is: " + report.getDatetime());
        print("Associated Skill tag is: " + report.getAssociatedskilltag());
        print("Total time played is: " + report.getPlaytime());
        print("Total number of interaction in game:" + report.getTotalnoofinteraction());
        print("percentage completed in game:" + report.getPercentage());
        print("Mode selected is: " + report.getSelectedmode());
        print("Subtitle is: " + report.getSubtitle());
        print("has tutorial: " + report.getHastutorial());
        print("Corrected guess are: " + report.getCorrectlyguessedselections());
        print("wring guess are: " + report.getWronglyguessedselections());

    }

     #region storejson
    //       public void SaveItemInfo()
    //     {
    //         string path = null;
    // #if UNITY_EDITOR
    //         path = "Assets/ItemInfo.json";
    // #endif
    // #if UNITY_STANDALONE
    //          // You cannot add a subfolder, at least it does not work for me
    //          path = "MyGame_Data/Resources/ItemInfo.json"
    // #endif

    //         //string str = ItemInfo.ToString();
    //         //  string json = JsonConvert.SerializeObject(report);
    //         string json = JsonUtility.ToJson(report);
    //         Debug.Log(json);
    //         using (FileStream fs = new FileStream(path, FileMode.Create))
    //         {
    //             using (StreamWriter writer = new StreamWriter(fs))
    //             {
    //                 writer.Write(json);
    //             }
    //         }
    // #if UNITY_EDITOR
    //         UnityEditor.AssetDatabase.Refresh();
    // #endif
    //     }
     #endregion

    #endregion
}
