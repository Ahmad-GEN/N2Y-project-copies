﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TargetScript : MonoBehaviour, AcessibilityInterface
{
    public string uniqueText = "panelOne";
    public int timeToWaitToPlayTextATStart = 3;
    public int soundIndex = 2;
    public string textToSayOnWait;
    public bool removeTarget = false;
    public bool EnableAccessability = false;
    public List<GameObject> list;
    public List<AccessibiltyObject> accesabilityObject;
    public GameObject greenbox;
    RectTransform greenTransform;
    int currentListIndex = 0;
    bool enableTouch = false;
    bool isButton = false;
    GameObject buttonObject;
    GameObject tempObject;

    [SerializeField] private float minimumSwipeDistanceY;
    [SerializeField] private float minimumSwipeDistanceX;

    private Touch t = default(Touch);
    private Vector3 startPosition = Vector3.zero;




    /// <summary>
    /// This function is called when the behaviour becomes disabled or inactive.
    /// </summary>
    void OnDisable()
    {
        if (GameManager.Instance.Accessibilty)
        {
            print("Going to disable the target script for object " + gameObject.name);

            accesabilityObject.Clear();
            currentListIndex = 0;
            isButton = false;
        }

    }

    /// <summary>
    /// Start is called on the frame when a script is enabled just before
    /// any of the Update methods is called the first time.
    /// </summary>
    void OnEnable()
    {
        if (GameManager.Instance.Accessibilty)
        {
            AccessibilityManager.instance.enablepause = true;
            Debug.Log("##########################################");
            currentListIndex = 0;

            greenTransform = greenbox.GetComponent<RectTransform>();

            GreenBoxNaviagtionAndAudio(greenTransform, list[currentListIndex]);

        }
    }
    /// <summary>
    /// This function is called when the object becomes enabled and active.
    /// </summary>
    void Awake()
    {
        GameObject obj;
        if (GameManager.Instance.Accessibilty)
        {
            // for (int i = 0; i < transform.childCount; i++)
            // {
            //     obj = transform.GetChild(i).gameObject;
            //     list.Add(obj);
            //     if (i == 0)
            //     {
            //         obj.GetComponent<TextToSpeak>().textToSpeak = "sprinkle cookie";
            //     }
            //     else if (i == 1)
            //     {
            //         obj.GetComponent<TextToSpeak>().textToSpeak = "chocolate chip cookie";
            //     }
            //     else if (i == 2)
            //     {
            //         obj.GetComponent<TextToSpeak>().textToSpeak = "striped cookie";
            //     }
            //     else if (i == 3)
            //     {
            //         obj.GetComponent<TextToSpeak>().textToSpeak = "chocolate cookie";
            //     }
            //     else if (i == 4)
            //     {
            //         obj.GetComponent<TextToSpeak>().textToSpeak = "jelly cookie";
            //     }
            //     else if (i == 5)
            //     {
            //         obj.GetComponent<TextToSpeak>().textToSpeak = "sugar cookie";
            //     }
            // }
            AccessibilityManager.instance.populateAccessibiltyList(accesabilityObject, list, uniqueText);
        }


    }

    void GreenBoxNaviagtionAndAudio(RectTransform green, GameObject gameObject)
    {

        if (gameObject.GetComponent<Button>()) // check if the object has button then in order to perform its event we will add a boolen
        {
            print("button found");
            isButton = true;
            buttonObject = gameObject;
        }
        else
        {
            isButton = false;
            buttonObject = null;
        }
        //  TextToSpeech.ins.onclick(gameObject.name);
        //   yield return new WaitForSeconds(0.5f);
        // Debug.Log(gameObject.name);
        // Debug.Log(green.name);
        // Debug.Log(green.parent.name);
        RectTransform list = gameObject.GetComponent<RectTransform>();
        green.parent = list.parent;
        //    green.SetSiblingIndex(0);
        green.anchorMin = list.anchorMin;
        green.anchorMax = list.anchorMax;
        green.anchoredPosition = list.anchoredPosition;
        green.sizeDelta = list.sizeDelta;
        green.eulerAngles = list.eulerAngles;
        enableTouch = true;



    }


    public void revertOption()
    {
        tempObject.SetActive(true);
        list.Add(tempObject);
    }
    public void changeState(bool state)
    {
        greenTransform = greenbox.GetComponent<RectTransform>();
        EnableAccessability = false;
        currentListIndex = list.Count - 1;
        Debug.Log("changing state of  " + gameObject.name + "    " + state + " count  " + list.Count.ToString());
        if (list.Count > 0 && state)
        {
            // TextToSpeech.ins.playtext("navigate through target");
            GreenBoxNaviagtionAndAudio(greenTransform, list[currentListIndex]);

            Invoke("wait", timeToWaitToPlayTextATStart);
        }


        // StartCoroutine(delay(state));

    }
    // IEnumerator delay(bool state)
    // {
    //     yield return new WaitForSeconds(3);
    //     greenTransform = greenbox.GetComponent<RectTransform>();
    //     EnableAccessability = false;
    //     currentListIndex = list.Count - 1;
    //     Debug.Log("changing state of  " + gameObject.name + "    " + state + " count  " + list.Count.ToString());
    //     if (list.Count > 0 && state)
    //     {
    //         // TextToSpeech.ins.playtext("navigate through target");
    //         GreenBoxNaviagtionAndAudio(greenTransform, list[currentListIndex]);
    //         StartCoroutine(wait());
    //     }
    // }
    void playsound(GameObject gameObject)
    {
        if (accesabilityObject.Exists(x => x.gameobject == gameObject))// will call to play sound by find object in accessability 
        {
            TextToSpeech.ins.playAudio(accesabilityObject.Find(y => y.gameobject == gameObject).clip);
        }
    }
    public void moveForward()
    {
        if (EnableAccessability)
        {
            if (currentListIndex > 0)
            {
                // Debug.Log("up " + currentListIndex);
                //StartCoroutine(CopyTransform(greenTransform, list[currentListIndex - 1]));
                currentListIndex--;
                playsound(list[currentListIndex]);
                GreenBoxNaviagtionAndAudio(greenTransform, list[currentListIndex]);

            }
            else
            {
                currentListIndex = list.Count - 1;
                playsound(list[currentListIndex]);
                GreenBoxNaviagtionAndAudio(greenTransform, list[currentListIndex]);

            }
        }

    }
    public void moveBackward()
    {
        if (EnableAccessability)
        {

            if (currentListIndex < list.Count - 1)
            {

                currentListIndex++;
                playsound(list[currentListIndex]);
                GreenBoxNaviagtionAndAudio(greenTransform, list[currentListIndex]);


            }
            else

            {
                currentListIndex = 0;
                playsound(list[currentListIndex]);
                GreenBoxNaviagtionAndAudio(greenTransform, list[currentListIndex]);

            }
        }
    }
    public void select()
    {
        if (EnableAccessability)
        {
            if (AccessibilityManager.instance.DragnDrop)
            {
                print("drag n drop");
                if (removeTarget)
                {
                    Debug.Log("curr index is  " + currentListIndex + " length is " + list.Count + " obj is " + gameObject.name);
                    if (list != null)
                    {
                        tempObject = list[currentListIndex];
                        list[currentListIndex].SetActive(false);
                        list.RemoveAt(currentListIndex);
                    }
                    else
                    {
                        Debug.Log("list is empty" + list.Count);
                    }
                }
                //  TextToSpeech.ins.playAudioThroughText(tempObject.GetComponent<TextToSpeak>().textToSpeak + " selected");

                AccessibilityManager.instance.SwitchToNextState(tempObject);
            }
            else
            {
                print("simple");
                if (isButton)
                {
                    Debug.Log("touch of " + gameObject.name);
                    isButton = false;
                    buttonObject.GetComponent<Button>().onClick.Invoke();
                    GreenBoxNaviagtionAndAudio(greenTransform, list[currentListIndex]);
                    if (buttonObject.GetComponent<TextToSpeak>())
                    {
                        if (buttonObject.GetComponent<TextToSpeak>().changeState)
                        {

                            AccessibilityManager.instance.SwitchToNextState(null);
                        }
                    }


                }

            }
        }


    }
    public void unselect()
    {
        if (EnableAccessability)
        {
            AccessibilityManager.instance.revertBackToTarget();
        }

    }
    public void infoText()
    {
        //  TextToSpeech.ins.playAudio(AccessibilityManager.instance.infolips[soundIndex]);
        if (EnableAccessability)
        {
            // TextToSpeech.ins.playLongAudio();
            TextToSpeech.ins.playAudio(AccessibilityManager.instance.infolips[soundIndex]);
        }

    }
    public string getWaitText()
    {
        return textToSayOnWait;
    }
    public void toggleNavigation(bool state)
    {
        EnableAccessability = state;
    }
    void wait()
    {

        if (AccessibilityManager.instance.clips.Count > 0)
            TextToSpeech.ins.playAudio(AccessibilityManager.instance.clips[soundIndex]);
        EnableAccessability = true;
    }
}
