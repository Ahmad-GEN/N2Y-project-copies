﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
[System.Serializable]
public class AccessibiltyObject // 
{

    public GameObject gameobject;
    public AudioClip clip;
}
public class listhandler : MonoBehaviour, AcessibilityInterface
{
    public string uniqueText = "ending";
    public string textToSayOnWait;
    public int soundIndex;
    public int timeToWaitToPlayTextATStart;
    public bool EnableAccessability = false;
    public GameObject[] extraResource;
    public List<GameObject> list;
    public List<AccessibiltyObject> accesabilityObject;
    public GameObject greenbox;
    RectTransform greenTransform;
    int currentListIndex = 0;
    bool enableTouch = false;
    bool isButton = false;
    GameObject buttonObject;

    /// <summary>
    /// This function is called when the behaviour becomes disabled or inactive.
    /// </summary>
    void OnDisable()
    {
        //  AccessibilityManager.ins.levelCompleted -= levelcompleted;

       // accesabilityObject.Clear();
        currentListIndex = 0;
        isButton = false;
    }

    /// <summary>
    /// Start is called on the frame when a script is enabled just before
    /// any of the Update methods is called the first time.
    /// </summary>
    void OnEnable()
    {

        currentListIndex = 0;
        
        greenTransform = greenbox.GetComponent<RectTransform>();
        GreenBoxNaviagtionAndAudio(greenTransform, list[currentListIndex]);
    }
    /// <summary>
    /// This function is called when the object becomes enabled and active.
    /// </summary>
    void Awake()
    {
        StartCoroutine(Delay());
    }
    IEnumerator Delay()
    {
        yield return new WaitForSeconds(0.5f);
        print(GameManager.Instance.Accessibilty);
        if (GameManager.Instance.Accessibilty == true)
        {
            AccessibilityManager.instance.populateAccessibiltyList(accesabilityObject, list,uniqueText);
        }
    }


    void GreenBoxNaviagtionAndAudio(RectTransform green, GameObject gameObject)
    {
        if (gameObject.GetComponent<Button>() != null) // check if the object has button then in order to perform its event we will add a boolen
        {
            isButton = true;
            buttonObject = gameObject;
        }
        else
        {
            isButton = false;
            buttonObject = null;
        }

        RectTransform list = gameObject.GetComponent<RectTransform>();
        green.parent = list.parent;
        green.anchorMin = list.anchorMin;
        green.anchorMax = list.anchorMax;
        green.anchoredPosition = list.anchoredPosition;
        green.sizeDelta = list.sizeDelta;
        green.eulerAngles = list.eulerAngles;
        enableTouch = true;



    }
    public void changeState(bool state)
    {
        Debug.Log("changing state of  " + gameObject.name + "    " + state);
        EnableAccessability = false;

        if (state)
        {
            Invoke("wait", timeToWaitToPlayTextATStart);

        }
    }
    public void revertOption()
    {

    }
    void playsound(GameObject gameobject)
    {
        if (accesabilityObject.Exists(x => x.gameobject == gameobject))// will call to play sound by find object in accessability 
        {
            TextToSpeech.ins.playAudio(accesabilityObject.Find(y => y.gameobject == gameobject).clip);
        }
    }
    public void moveForward()
    {
        if (EnableAccessability)
        {
            if (currentListIndex > 0)
            {
                Debug.Log("up " + currentListIndex);
                currentListIndex--;
                playsound(list[currentListIndex]);
                GreenBoxNaviagtionAndAudio(greenTransform, list[currentListIndex]);
            }
            else
            {
                currentListIndex = list.Count - 1;
                playsound(list[currentListIndex]);
                print("the length is  " + list.Count + "cuur " + currentListIndex);
                GreenBoxNaviagtionAndAudio(greenTransform, list[currentListIndex]);
            }
        }

    }
    public void moveBackward()
    {
        if (EnableAccessability)
        {

            if (currentListIndex < list.Count - 1)
            {
                currentListIndex++;
                playsound(list[currentListIndex]);
                GreenBoxNaviagtionAndAudio(greenTransform, list[currentListIndex]);
            }
            else
            {
                currentListIndex = 0;
                playsound(list[currentListIndex]);
                GreenBoxNaviagtionAndAudio(greenTransform, list[currentListIndex]);
            }
        }
    }
    public void select()
    {
        if (EnableAccessability)
        {
            if (isButton)
            {
                Debug.Log("touch of " + gameObject.name);
                isButton = false;
                buttonObject.GetComponent<Button>().onClick.Invoke();
                AccessibilityManager.instance.SwitchToNextState(null);


            }
        }


    }
    public void infoText()
    {
        TextToSpeech.ins.playAudio(AccessibilityManager.instance.infolips[soundIndex]);
    }
    public void unselect()
    {

    }
    public string getWaitText()
    {
        return textToSayOnWait;
    }
     public void toggleNavigation(bool state)
    {
        EnableAccessability = state;
    }
    void wait()
    {
        // yield return new WaitForSeconds(timeToWaitToPlayTextATStart);
        if(AccessibilityManager.instance.clips.Count>0)
        TextToSpeech.ins.playAudio(AccessibilityManager.instance.clips[soundIndex]);
        EnableAccessability = true;
    }

}
