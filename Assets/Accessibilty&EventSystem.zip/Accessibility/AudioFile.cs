﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioFile : MonoBehaviour
{

    public string[] inGameString;
    public string[] MainMenuString;
    public string[] destinationString;
    public string[] panelOneString;
    public string[] panelTwoString;

    public string[] panelThreeString;
    public string[] panelFourString;
    public string[] endingString;
    public string[] othersString;

   [HideInInspector]
    public List<AudioClip> waitText,MainMenu,destination,panelOne,panelTwo,panelThree,panelFour,ending,others;

    [HideInInspector]
    public static AudioFile instance;

    /// <summary>
    /// Start is called on the frame when a script is enabled just before
    /// any of the Update methods is called the first time.
    /// </summary>
    void Start()
    {
        print("audiofile");
        instance = this;
        download();
    }
    public void download()
    {

        TextToSpeech.ins.DowloadStartingSound(MainMenuString, MainMenu);
        TextToSpeech.ins.DowloadStartingSound(inGameString, AccessibilityManager.instance.clips);
        TextToSpeech.ins.DowloadStartingSound(inGameString, AccessibilityManager.instance.infolips);
      //  TextToSpeech.ins.DowloadStartingSound(inGameString, waitText);
        TextToSpeech.ins.DowloadStartingSound(panelOneString, panelOne);
        TextToSpeech.ins.DowloadStartingSound(panelTwoString, panelTwo);
        TextToSpeech.ins.DowloadStartingSound(panelThreeString, panelThree);
        TextToSpeech.ins.DowloadStartingSound(panelFourString, panelFour);
        TextToSpeech.ins.DowloadStartingSound(destinationString, destination);
        TextToSpeech.ins.DowloadStartingSound(othersString, others);
        TextToSpeech.ins.DowloadStartingSound(endingString, ending);


    }
}
