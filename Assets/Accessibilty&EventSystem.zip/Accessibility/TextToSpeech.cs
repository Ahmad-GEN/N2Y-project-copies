﻿using UnityEngine.UI;
//using Newtonsoft.Json;
using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using System.Linq;
using System.Linq.Expressions;
using System.Text.RegularExpressions;


public class TextToSpeech : MonoBehaviour
{
    public int i = 1, cookieNum = 1;
    bool wait = false;

    // private string key = "1246840dec93420a9e1f199bfdb3ae85"; //arslan
    // private string key = "d4856606d9de439aa37ce4d9e53ec0e1";//zaki
    private string key = "01732f50d4a843fca98dd8eddfaa3ee9";
    //private string key = "";
    public AudioSource source;
    private AudioClip clip;
    //public InputField inputText;
    string text;
    [HideInInspector]
    //public Queue<AudioClip> sound = new Queue<AudioClip>();
    public static TextToSpeech ins;
    public bool justtext = false;
    /// <summary>
    /// Start is called on the frame when a script is enabled just before
    /// any of the Update methods is called the first time.
    /// </summary>
    void OnEnable()
    {

        // playtext("Kindly navigate the game using buttons");
        if (GetComponent<AudioSource>() != null)
            source = GetComponent<AudioSource>();
        ins = this;
    }
    IEnumerator downloadAudio(AccessibiltyObject t)
    {
        Regex rg = new Regex("\\s+");
        string result = rg.Replace(text, "+");
        //		print(result.ToString());

        string url = "http://api.voicerss.org/?key=" + key + "&hl=en-us&src=" + result + "&c=WAV"; 
        //string url = "https://l3skills.n2y.com/api/speechapi/GetDynamicSpeechData?text=spech "+ result +"&speed=30&volume=90&speechLanguage=en";//n2y server
        WWW ww = new WWW(url);
        yield return ww;
        //	source.clip = ww.GetAudioClip(false,false,AudioType.MPEG);
        //sound.Enqueue(ww.GetAudioClip(false,false,AudioType.MPEG));
        //source.Play();
        if (justtext)
            playAudio(ww.GetAudioClip(false, false, AudioType.WAV));
        else
        {
            if (t != null)
                t.clip = ww.GetAudioClip(false, false, AudioType.WAV);
        }


        justtext = false;

    }
    public void DownloadAllAudios(AccessibiltyObject t)
    {
        if (t.gameobject.GetComponent<TextToSpeak>())
        {
            text = t.gameobject.GetComponent<TextToSpeak>().textToSpeak;
        }
        else
        {
            text = t.gameobject.name;
        }
        StartCoroutine(downloadAudio(t));
    }
    public void playAudio(AudioClip clip)
    {
        if (clip != null)
        {
            // print("playing sound");
            source.clip = clip;
            source.Play();
        }

    }
    public void playAudioThroughText(string t)
    {
        justtext = true;
        text = t;
        StartCoroutine(downloadAudio(null));
    }

    public void DowloadStartingSound(string[] text, List<AudioClip> clips)
    {
      
        clips.Clear();
        StartCoroutine(Download(text, clips));

    }
    IEnumerator Download(string[] text, List<AudioClip> clips)
    { 

        for (int i = 0; i < text.Length; i++)
        {
            Regex rg = new Regex("\\s+");
            string result = rg.Replace(text[i], "+");
            string url = "http://api.voicerss.org/?key=" + key + "&hl=en-us&src=" + result + "&c=WAV";
           // string url = "https://l3skills.n2y.com/api/speechapi/GetDynamicSpeechData?text=spech "+ result +"&speed=30&volume=90&speechLanguage=en";//n2y server
       
            WWW ww = new WWW(url);
            yield return ww;
            clips.Add(ww.GetAudioClip(false, false, AudioType.WAV));
        }

    }
    public void playLongAudio(int i, int cookieNum)
    {
        if (GameManager.Instance.Accessibilty)
        {
            if (wait == false)
                StartCoroutine(playIT(i, cookieNum));
        }
    }
    public void playLongAudio()
    {
        if (GameManager.Instance.Accessibilty)
        {
            if (wait == false)
                StartCoroutine(playIT(i, cookieNum));
        }

    }
    IEnumerator playIT(int i, int cookieNum)
    {
        yield return new WaitForSeconds(0.1f);
        // float gap = 0.75f;
        // wait = true;
        // AccessibilityManager.instance.ToggleNaviagtion(false); //arslan
        // yield return new WaitForSeconds(01);
        // //kindly select
        // source.clip = AudioFile.instance.others[0];
        // source.Play();
        // yield return new WaitForSeconds(source.clip.length-gap);
        // //num of cookie

        // source.clip = AudioFile.instance.numbers[i];
        // source.Play();
        // yield return new WaitForSeconds(source.clip.length-gap);
        // //cookie nam
        // if (i == 0)
        // {
        //     source.clip = AudioFile.instance.cookie[cookieNum];
        //     source.Play();
        //     yield return new WaitForSeconds(source.clip.length-gap);
        // }
        // else
        // {
        //     source.clip = AudioFile.instance.cookies[cookieNum];
        //     source.Play();
        //     yield return new WaitForSeconds(source.clip.length-gap);
        // }
        // AccessibilityManager.instance.ToggleNaviagtion(true); //arslan
        // wait = false;
    }
}
